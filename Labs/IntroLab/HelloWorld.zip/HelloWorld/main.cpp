#include <iostream>

void sayHello();

int main ()
{
    sayHello();
    return 0;
    
}


void sayHello()
{
    std::cout << "Hello World!" << std::endl;
}